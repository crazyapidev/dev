package com.cts.cdslab.opennlp.components.demo;

import opennlp.tools.tokenize.SimpleTokenizer;  
public class TokenizerExample { 
   public static void main(String args[]){ 
     
      String sentence = " Hi. How are you? Welcome to information extraction hands-on " 
 	         + "Let's explore various nlp pipelines";
    
      //Instantiating SimpleTokenizer class 
      SimpleTokenizer simpleTokenizer = SimpleTokenizer.INSTANCE;  
       
      //Tokenizing the given sentence 
      String tokens[] = simpleTokenizer.tokenize(sentence);  
       
      //Printing the tokens 
      for(String token : tokens) {         
         System.out.println(token);  
      }       
   }  
}