package com.cts.cdslab.ie;

import static org.apache.uima.fit.factory.AnalysisEngineFactory.createEngineDescription;
import static org.apache.uima.fit.factory.CollectionReaderFactory.createReaderDescription;

import java.io.File;

import org.apache.uima.analysis_engine.AnalysisEngineDescription;
import org.apache.uima.collection.CollectionReaderDescription;
import org.apache.uima.fit.factory.AnalysisEngineFactory;
import org.apache.uima.fit.pipeline.SimplePipeline;

import com.cts.cdslab.ie.consumer.PrintTokenAnnotationsConsumer;
import com.cts.cdslab.ie.consumer.XmiWriter;
import com.cts.cdslab.ie.reader.SimpleDocumentReader;
import com.cts.cdslab.ie.util.OpennlpAe;

public class MainPipeline {
	public static void main(String[] args) {

		try {
			//document reader
			CollectionReaderDescription documentReader = createReaderDescription(SimpleDocumentReader.class,
					SimpleDocumentReader.PARAM_INPUT_DIR, "src/test/resources/texts");

			// Opennlp Engines
			AnalysisEngineDescription aeTokenizerDesc = OpennlpAe.getTokenizer();
			AnalysisEngineDescription aeSentenceDesc = OpennlpAe.getSentenceDetector();
			AnalysisEngineDescription aePosTagger = OpennlpAe.getPosTagger();
			AnalysisEngineDescription aeNER = OpennlpAe.getNER();
			
			//consumers
			AnalysisEngineDescription xmiWriter = createEngineDescription(XmiWriter.class,
					XmiWriter.PARAM_OUTPUT_DIRECTORY, "output");
			
			AnalysisEngineDescription annotationsPrinter = createEngineDescription(PrintTokenAnnotationsConsumer.class);
			

			

			SimplePipeline.runPipeline(documentReader, aeSentenceDesc, aeTokenizerDesc, aePosTagger,aeNER, xmiWriter,annotationsPrinter);

		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}