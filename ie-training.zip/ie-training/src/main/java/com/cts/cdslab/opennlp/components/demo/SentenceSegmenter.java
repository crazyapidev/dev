package com.cts.cdslab.opennlp.components.demo;

public class SentenceSegmenter {  
	   public static void main(String args[]){ 
	     
	      String sentence = " Hi. How are you? Welcome to information extraction hands-on " 
	  	         + "Let's explore various nlp pipelines";
	     
	      String simple = "[.?!]";      
	      String[] splitString = (sentence.split(simple));     
	      for (String string : splitString)   
	         System.out.println(string);      
	   } 
	}
