# IE-Training
Project containing some simple examples of uimaFIT annotators, consumers and document readers

This project requires maven 

`MainPipeline` is just an example of usage. You should configure it accordingly (inputs and outputs paths)






