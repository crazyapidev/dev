package com.cts.cdslab.uima;

import java.util.Iterator;

import org.apache.uima.analysis_engine.AnalysisEngine;
import org.apache.uima.cas.FSIndex;
import org.apache.uima.jcas.JCas;

/**
 * Tests for the Noun Phrase Annotator.
 */
public class NounPhraseAnnotatorTest {

  private static final String[] INPUTS = new String[] { "Testing the openNlp to detect NonnPhrases"};

 /* @Test
  public void testNounPhraseAnnotation() throws Exception {
    AnalysisEngine ae = UimaUtils.getAE(
      "conf/descriptors/NounPhraseAE.xml", null);
    for (String input : INPUTS) {
      System.out.println("text: " + input);
      JCas jcas = UimaUtils.runAE(ae, input, UimaUtils.MIMETYPE_TEXT);
      FSIndex index = jcas.getAnnotationIndex(NounPhraseAnnotation.type);
      for (Iterator<NounPhraseAnnotation> it = index.iterator(); it.hasNext();) {
        NounPhraseAnnotation annotation = it.next();
        System.out.println("...(" + annotation.getBegin() + "," + 
          annotation.getEnd() + "): " + 
          annotation.getCoveredText());
      }
    }
  }*/
}