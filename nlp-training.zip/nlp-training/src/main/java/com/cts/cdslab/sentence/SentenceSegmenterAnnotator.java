package com.cts.cdslab.sentence;

import static org.apache.uima.fit.factory.AnalysisEngineFactory.createEngine;

import org.apache.uima.UIMAException;
import org.apache.uima.analysis_engine.AnalysisEngine;
import org.apache.uima.fit.examples.getstarted.GetStartedQuickAE;
import org.apache.uima.fit.factory.AnalysisEngineFactory;
import org.apache.uima.fit.factory.JCasFactory;
import org.apache.uima.jcas.JCas;

public class SentenceSegmenterAnnotator {

	public static void main(String[] args) throws UIMAException {
		  String text = "The meeting was moved from Yorktown 01-144 to Hawthorne 1S-W33.";
		    AnalysisEngine analysisEngine = createEngine(GetStartedQuickAE.class);
		    JCas jCas = analysisEngine.newJCas();
		    jCas.setDocumentText(text);
		    analysisEngine.process(jCas);
	  }
}
